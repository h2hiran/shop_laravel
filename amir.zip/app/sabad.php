<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sabad extends Model
{
    protected $table='sabads';
}
