<?php 
    if ($data->level_menu==0)
         $listgroup0=1;
    elseif ($data->level_menu==1)
          $listgroup1=1;
          else
          $listgroup2=1;

    $group=1;
 ?>




<?php $__env->startSection('cat'); ?>
    <h1 class="m-0 text-dark">ویرایش کردن</h1>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <script>
        setTimeout(function(){
            $('#alert').remove();
        }, 2000);
    </script>
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">اطلاعات را کامل کنید</h3>
        </div>
        <?php if(isset($ok)): ?>
            <br>
            <span id="alert" class="alert alert-success"><label>ذخیره با موفقیت انجام گردید</label></span>
        <?php endif; ?>
        <!-- /.card-header -->
        <!-- form start -->
        <form role="form" method="post" action="/admin/list-menu/edite-menu/update/<?php echo e($data->id); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="card-body">
                <div class="form-group">
                    <label for="name">نام</label>
                    <input type="text" name="name" class="form-control" id="name" placeholder="نام دسته بندی را وارد کنید" required value="<?php echo e($data->name_menu); ?>">
                </div>
                <div class="form-group">
                    <label for="url">آدرس url</label>
                    <input type="text" name="seo" class="form-control" id="url" placeholder="آدرس url را وارد کنید" required value="<?php echo e($data->seo_menu); ?>">
                </div>
                <?php if($data->level_menu==1 || $data->level_menu==2): ?>
                <div class="form-group">
                    <select class="form-control" name="parent" required>
                        <?php $__currentLoopData = $men; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($value->id==$data->parent_menu): ?> selected <?php endif; ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name_menu); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php endif; ?>
                <div class="form-group">
                    <input class="btn btn-success" type="submit" value="ذخیره">
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php 
    if ($data->level_menu==0)
        $listgroup0=0;
   elseif ($data->level_menu==1)
         $listgroup1=0;
         else
         $listgroup2=0;

   $group=0;
 ?>
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>