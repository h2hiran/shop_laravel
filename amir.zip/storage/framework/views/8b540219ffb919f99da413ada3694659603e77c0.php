<?php
use Illuminate\Support\Facades\Session;
?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('header'); ?>
<!-- Page Title-->
<div class="page-title d-flex" aria-label="Page title" style="background-image: url(/img/page-title/shop-pattern.jpg);">
    <div class="container text-right align-self-center">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">صفحه اصلی</a>
                </li>
                <li class="breadcrumb-item"><a href="">فروشگاه</a>
                </li>
            </ol>
        </nav>
        <h1 class="page-title-heading">صفحه محصول</h1>
    </div>
</div>
<!-- Page Content-->
<div class="container mb-2">
    <div class="row">
        <!-- Product Gallery-->
        <div class="col-md-6 pb-5">
            <div class="product-gallery" style="min-height: 513px">
                <div class="product-carousel owl-carousel" data-owl-carousel="{ &quot;rtl&quot;: true}"><a class="gallery-item" href="/img/prodoct/<?php echo e($data[0]->pic); ?>" data-fancybox="gallery1" data-hash="one"><img src="/img/prodoct/<?php echo e($data[0]->pic); ?>" alt="Product"></a></div>
            </div>
        </div>
        <!-- Product Info-->
        <div class="col-md-6 pb-5">
            <div class="product-meta"><i class="fe-icon-bookmark"></i><a href="/category/<?php echo e($dasteh1->seo_menu); ?>"><?php echo e($dasteh1->name_menu); ?>,</a><a href="/category/<?php echo e($dasteh2->seo_menu); ?>"><?php echo e($dasteh2->name_menu); ?>,</a><a href="/category/<?php echo e($dasteh3->seo_menu); ?>"><?php echo e($dasteh3->name_menu); ?></a></div>
            <h2 class="h3 font-weight-bold"><?php echo e($data[0]->name); ?></h2>
            <h3 class="h4 font-weight-light">
                <?php if($data[0]->takhfif>0): ?>
                <del class="text-muted"><?php echo e(number_format($data[0]->gheymat)); ?></del>
                <?php echo e(number_format($data[0]->takhfif)); ?>  تومان
                    <?php else: ?>
                    <?php echo e(number_format($data[0]->gheymat)); ?>  تومان
                 <?php endif; ?>
            </h3>
                <?php $words=explode(" ",$data[0]->dis);  $dis = implode(" ",array_splice($words,0,100)); ?>
            <p class="text-muted"><?php echo e($dis); ?>  <a href='#details' class='scroll-to'>اطلاعات بیشتر</a></p>
            <div class="row mt-4">

            </div>
            <div class="row align-items-end pb-4">
                <div class="col-sm-4">
                    <div class="form-group mb-0">
                        <label for="quantity">تعداد</label>
                        <input type="number" class="form-control" id="quantity" value="1" min="1" max="10">
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="pt-4 hidden-sm-up"></div>
                    <button class="btn btn-primary btn-block m-0" data-toast data-toast-type="success" data-toast-position="topRight" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!" onclick="add_sabad(<?php echo e($data[0]->id); ?>)"><i class="fe-icon-shopping-cart"></i> افزودن به سبد خرید</button>
                </div>
            </div>


                <?php 
                    $classfave='fe-icon-heart';
                    $check=\App\prodoct::find($data[0]->id)->karbar()->where('karbar_id',session::get('login'))->get();
                    if ($check!='[]')
                     $classfave= 'fa fa-heart';
                     else
                     $classfave= 'fe-icon-heart';
                 ?>



            <hr class="mb-2">
            <div class="d-flex flex-wrap justify-content-between align-items-center">
                <div class="mt-2 mb-2">
                    <?php if(! session('login')): ?>
                         <div class="btn btn-danger btn-sm my-2 mr-1"><a style="color:white;text-decoration: none" href="/account-login"><i class="fe-icon-heart"></i> علاقمندی </a></div>
                    <?php else: ?>
                        <div class="btn btn-danger btn-sm my-2 mr-1"><a style="color:white;text-decoration: none" href="#" onclick="add_fav(<?php echo e($data[0]->id); ?>)" data-toast data-toast-type="info" data-toast-position="topRight" data-toast-icon="fe-icon-info" data-toast-title="محصول" data-toast-message="به لیست علاقمندی های شما اضافه شد!"><i  id="class<?php echo e($data[0]->id); ?>" class="<?php echo e($classfave); ?>"></i> علاقمندی </a></div>
                    <?php endif; ?>
                </div>
                <div class="mt-2 mb-2"><span class="text-muted d-inline-block align-middle mb-2">اشتراک:&nbsp;&nbsp;</span>
                    <div class="d-inline-block"><a class="social-btn sb-style-3 sb-facebook my-1" href="#" data-toggle="tooltip" data-placement="top" title="Facebook"><i class="socicon-facebook"></i></a><a class="social-btn sb-style-3 sb-twitter my-1" href="#" data-toggle="tooltip" data-placement="top" title="Twitter"><i class="socicon-twitter"></i></a><a class="social-btn sb-style-3 sb-instagram my-1" href="#" data-toggle="tooltip" data-placement="top" title="Instagram"><i class="socicon-instagram"></i></a><a class="social-btn sb-style-3 sb-google-plus my-1 mr-0" href="#" data-toggle="tooltip" data-placement="top" title="Google +"><i class="socicon-googleplus"></i></a></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Product Details-->
<div class="bg-secondary pt-5 pb-4" id="details">
    <div class="container py-2">
        <div class="row">
            <div class="col-md-12">
                <h3 class="h6">جزئیات</h3>
                <p class="mb-4 pb-2"><?php echo e(htmlspecialchars_decode($data[0]->dis)); ?></p>
                <h3 class="h6">امکانات</h3>
                <ul class="list-icon mb-4 pb-2">
                    <?php $__currentLoopData = $vizh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><i class="fe-icon-check text-success"></i><?php echo e($val); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Reviews-->

    
        
            
                
                    
                        
                        
                            
                            
                        
                    
                    
                        
                            
                        
                        
                            
                        
                        
                            
                        
                        
                            
                        
                        
                            
                        
                    
                    
                
            
        
        
            
                
            
            
            
                
                    
                    
                    
                
                
                
                    
                    
                    
                        
                            
                        
                    
                
            
            
            
                
                    
                    
                    
                
                
                
                    
                    
                    
                        
                            
                        
                    
                
            
        
    


<br>
<br>
<br>
<div class="container pt-3 pb-5">
    <!-- Related Products Carousel-->
    <h3 class="h4 text-center pb-4">شاید دوست داشته باشید</h3>
    <div class="owl-carousel carousel-flush" data-owl-carousel="{ &quot;rtl&quot;: true,&quot;nav&quot;: false, &quot;dots&quot;: true,&quot;responsive&quot;: {&quot;0&quot;:{&quot;items&quot;:1},&quot;576&quot;:{&quot;items&quot;:2},&quot;768&quot;:{&quot;items&quot;:3},&quot;991&quot;:{&quot;items&quot;:4},&quot;1200&quot;:{&quot;items&quot;:4}} }">


        <?php $__currentLoopData = $love; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Product-->
        <div class="product-card mx-auto mb-5" style="height:475px;">
            <div class="product-head d-flex justify-content-between align-items-center" >
            </div><a class="product-thumb" href="/prodoct/<?php echo e($value->seo); ?>"><img src="/img/prodoct/<?php echo e($value->pic); ?>" alt="Product Thumbnail"/></a>
            <div class="product-card-body"><a class="product-meta" href="shop-categories.html">اسپیکر(بلندگو)</a>
                <h5 class="product-title"><a href="shop-single.html"><?php echo e($value->name); ?></a></h5><span class="product-price">
                    <?php if($value->takhfif>0): ?>
                        <?php echo e($value->takhfif); ?><del><?php echo e($value->gheymat); ?></del> تومان</span>
                        <?php else: ?>
                         <?php echo e($value->gheymat); ?>

                    <?php endif; ?>

            </div>
            <div class="product-buttons-wrap">
                <div class="product-buttons">


                    <?php 
                        $classfave='fe-icon-heart';
                        $check=\App\prodoct::find($value->id)->karbar()->where('karbar_id',session::get('login'))->get();
                        if ($check!='[]')
                         $classfave= 'fa fa-heart';
                         else
                         $classfave= 'fe-icon-heart';
                     ?>


                    <?php if(! session('login')): ?>
                        <div class="product-button"><a href="/account-login"><i class="fe-icon-heart"></i></a></div>
                    <?php else: ?>
                        <div class="product-button"><a href="#" onclick="add_fav(<?php echo e($value->id); ?>)" data-toast data-toast-position="topRight" data-toast-type="info" data-toast-icon="fe-icon-help-circle" data-toast-title="علاقه مندی" data-toast-message="با موفقیت انجام گردید"><i  id="class<?php echo e($value->id); ?>" class="<?php echo e($classfave); ?>"></i></a></div>
                    <?php endif; ?>

                    <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="success" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!" onclick="sabad(<?php echo e($value->id); ?>)"><i class="fe-icon-shopping-cart"></i></a></div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</div>


<?php echo $__env->yieldContent('footer'); ?>