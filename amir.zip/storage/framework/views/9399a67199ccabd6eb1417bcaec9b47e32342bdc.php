<?php

namespace App;


use \App\menu;
use \Illuminate\Support\Facades\DB;


$id=$_POST['id'];

//$data=menu::where('parent_menu',$id)->get();
$data=DB::table('menus')->where('parent_menu', $id)->get();

$option='<option value="0">انتخاب کنید</option>';


while ($row=$data->fetch_array())
{
    $option.='<option value="'.$row["id"].'">'.$row["name_menu"].'</option>';
}

//echo $option;
echo $data;
?>



