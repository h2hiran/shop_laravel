<?php
use Illuminate\Support\Facades\Session;
?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('header'); ?>
    <!-- Page Title-->
    <div class="page-title d-flex" aria-label="Page title" style="background-image: url(/img/page-title/shop-pattern.jpg);">
        <div class="container text-right align-self-center">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">صفحه اصلی</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">فروشگاه</a>
                    </li>
                </ol>
            </nav>
            <h1 class="page-title-heading">فروشگاه</h1>
        </div>
    </div>
    <!-- Page Content-->
    <div class="container pb-5 mb-3">
        <div class="row">
            <div class="col-lg-3">
                <!-- Shop Sidebar-->
                <!-- Off-Canvas Toggle--><a class="offcanvas-toggle" href="#shop-sidebar" data-toggle="offcanvas"><i class="fe-icon-sidebar"></i></a>
                <!-- Off-Canvas Container-->
                <aside class="offcanvas-container" id="shop-sidebar">
                    <div class="offcanvas-scrollable-area px-4 pt-5 px-lg-0 pt-lg-0"><span class="offcanvas-close"><i class="fe-icon-x"></i></span>
                        <!-- Categories-->
                        <div class="widget widget-categories">
                            <h4 class="widget-title">دسته بندی</h4>
                            <ul>
                          <?php   $show='show';  ?>
                            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($val->level_menu==0): ?>
                                <li>
                                    <a href="#<?php echo e($val->seo_menu); ?>" data-toggle="collapse"><?php echo e($val->name_menu); ?></a>
                                    <div class="collapse <?php echo e($show); ?>" id="<?php echo e($val->seo_menu); ?>">
                                        <ul>
                                            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($value->parent_menu==$val->id): ?>
                                                     <li><a href="/category/<?php echo e($value->seo_menu); ?>"><?php echo e($value->name_menu); ?></a></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </li>
                                    <?php  $show='null';  ?>
                                 <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>

                        <!-- Popular products-->
                        <div class="widget widget-featured-products">
                            <h4 class="widget-title">محصولات محبوب</h4>

                        <?php $__currentLoopData = $sabad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?Php $fav=\Illuminate\Support\Facades\DB::table('prodocts')->where('id',$val->prodoct_id)->get(); ?>
                            <?php if($fav): ?>
                            <a class="featured-product" href="/prodoct/<?php echo e($fav[0]->seo); ?>">
                                <div class="featured-product-thumb"><img src="/img/prodoct/<?php echo e($fav[0]->pic); ?>" alt="Product Image"/>
                                </div>
                                <div class="featured-product-info">
                                    <h5 class="featured-product-title"><?php echo e($fav[0]->name); ?></h5>
                                  <span class="featured-product-price">
                                      <?php if($fav[0]->takhfif>0): ?>

                                        <?php echo e($fav[0]->takhfif); ?>&nbsp;<del><?php echo e($fav[0]->gheymat); ?></del> تومان
                                          <?php else: ?>
                                          <?php echo e($fav[0]->gheymat); ?>&nbsp; تومان
                                        <?php endif; ?>
                                  </span>
                                </div>
                            </a>
                                <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </aside>
            </div>
            <div class="col-lg-9">
                <!-- Shop Grid-->
                <div class="row">
                <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($val->dasteh3==$value->id): ?>
                            <?php  $cat=$value->name_menu;  ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    <?php 
                        $classfave='fe-icon-heart';
                        $check=\App\prodoct::find($val->id)->karbar()->where('karbar_id',session::get('login'))->get();
                        if ($check!='[]')
                         $classfave= 'fa fa-heart';
                         else
                         $classfave= 'fe-icon-heart';
                     ?>



                    <!-- Product-->
                    <div class="col-md-4 col-sm-6 mb-30">
                        <div class="product-card mx-auto mb-3">
                            <div class="product-head d-flex justify-content-between align-items-center">
                            </div><a class="product-thumb" href="/prodoct/<?php echo e($val->seo); ?>"><img src="/img/prodoct/<?php echo e($val->pic); ?>" alt="Product Thumbnail"/></a>
                            <div class="product-card-body"><a class="product-meta" href=""><?php echo e($cat); ?></a>
                                <h5 class="product-title"><a href="/prodoct/<?php echo e($val->seo); ?>"><?php echo e($val->name); ?></a></h5><span class="product-price">
                                    <?php if($val->takhfif>0): ?>
                                       <?php echo e($val->takhfif); ?><del><?php echo e($val->gheymat); ?></del> تومان
                                    <?php else: ?>
                                    <?php echo e($val->gheymat); ?>   تومان
                                    <?php endif; ?>
                                </span>
                            </div>
                            <div class="product-buttons-wrap">
                                <div class="product-buttons">
                                    <?php if(! session('login')): ?>
                                        <div class="product-button"><a href="/account-login"><i class="fe-icon-heart"></i></a></div>
                                    <?php else: ?>
                                        <div class="product-button"><a href="#" onclick="add_fav(<?php echo e($val->id); ?>)" data-toast data-toast-position="topRight" data-toast-type="info" data-toast-icon="fe-icon-help-circle" data-toast-title="علاقه مندی" data-toast-message="با موفقیت انجام گردید"><i  id="class<?php echo e($val->id); ?>" class="<?php echo e($classfave); ?>"></i></a></div>
                                    <?php endif; ?>
                                    <div class="product-button"><a href="#" onclick="sabad(<?php echo e($val->id); ?>)" data-toast data-toast-position="topRight" data-toast-type="success" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!"><i class="fe-icon-shopping-cart"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <br>
                <br>
                <?php echo e($pro->links()); ?>


            </div>
        </div>
    </div>
<?php echo $__env->yieldContent('footer'); ?>