<?php 
if ($status=='we')
    $listwe=1;
else
$listspe=1;
$setting=1;
 ?>


<?php $__env->startSection('cat'); ?>
    <h1 class="m-0 text-dark">تنظیمات</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <script>
        setTimeout(function(){
            $('#alert').remove();
        }, 2000);
    </script>
    <div class="card card-primary">
        <?php if(! isset($_GET['status'])): ?>
            <div class="card-header" style="margin-bottom: 20px">
                <h3 class="card-title"></h3>
            </div>
        <?php else: ?>
            <div class="card-header" style="margin-bottom: 20px;background-color: #980110">
                <h3 id="alert" class="card-title">ارور: ابتدا زیر گروه را پاک کنید</h3>
            </div>
        <?php endif; ?>
        <table class="table table-bordered table-striped" id="example1">
            <thead>
            <tr style="text-align: center">
                <th scope="col">#</th>
                <th scope="col">نام</th>
                <th scope="col">seo</th>
                <th scope="col">وضعیت</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($value->id); ?></th>
                    <td><?php echo e($value->name); ?></td>
                    <td><?php echo e($value->seo); ?></td>
                    <?php if(($status=='we')): ?>
                    <?php if($value->suggestion>0): ?>
                    <td><a href="/admin/store-setting/1/<?php echo e($value->id); ?>/0" class="btn-success ">فعال</a></td>
                        <?php else: ?>
                        <td><a href="/admin/store-setting/1/<?php echo e($value->id); ?>/1" class="btn-danger ">غیرفعال</a></td>
                    <?php endif; ?>
                        <?php else: ?>
                        <?php if($value->special>0): ?>
                            <td><a href="/admin/store-setting/2/<?php echo e($value->id); ?>/0" class="btn-success ">فعال</a></td>
                        <?php else: ?>
                            <td><a href="/admin/store-setting/2/<?php echo e($value->id); ?>/1" class="btn-danger ">غیرفعال</a></td>
                        <?php endif; ?>
                        <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('java'); ?>
    <script>
        $(function () {
            $("#example1").DataTable({
                "language": {
                    "paginate": {
                        "next": "بعدی",
                        "previous" : "قبلی"
                    }
                },
                "info" : false,
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php 
    if ($status=='we')
         $listwe=0;
         else
        $listspe=1;

$setting=0;
 ?>
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>