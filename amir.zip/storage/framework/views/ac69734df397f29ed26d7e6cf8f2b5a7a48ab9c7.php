<?php
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
$fav=DB::table('prodoct_karbar')->where('karbar_id',session::get('login'))->get();
?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('header'); ?>

      <!-- Page Content-->
      <!-- Hero Slider-->
      <section class="featured-posts-slider d-lg-flex" style="margin-bottom: 100px">
        <div class="column">
          <div class="owl-carousel post-preview-img-carousel" data-owl-carousel="{ &quot;rtl&quot;: true, &quot;nav&quot;: false, &quot;dots&quot;: false, &quot;loop&quot;: true, &quot;mouseDrag&quot;: false, &quot;touchDrag&quot;: false, &quot;pullDrag&quot;: false }"><a class="post-preview-img" href="shop-boxed-ft.html" style="background-image: url(img/homepages/shop-v1/hero-slide01.jpg);"></a><a class="post-preview-img" href="shop-fw-ls.html" style="background-image: url(img/homepages/shop-v1/hero-slide02.jpg);"></a><a class="post-preview-img" href="shop-fw-ls.html" style="background-image: url(img/homepages/shop-v1/hero-slide03.jpg);"></a></div>
        </div>
        <div class="column">
          <div class="owl-carousel post-cards-carousel" data-owl-carousel="{ &quot;rtl&quot;: true, &quot;nav&quot;: true, &quot;dots&quot;: false, &quot;loop&quot;: true, &quot;autoHeight&quot;: true }">
            <div class="card-body"><img class="d-block mb-4" src="img/homepages/shop-v1/dji-logo.png" style="width: 215px !important;" alt="DJI">
              <h2 class="block-title pb-4 mb-3">عکاسی هوایی و ویدئو را دوباره تصور کنید</h2>
              <p class="lead text-muted pb-3">شروع از <strong>۹,۵۰۰,۰۰۰ تومان</strong></p><a class="btn btn-style-5 btn-primary" href="shop-boxed-ft.html">خرید کنید&nbsp;<i class="fe-icon-arrow-left"></i></a>
            </div>
            <div class="card-body"><img class="d-block mb-4" src="img/homepages/shop-v1/canon-logo.png" style="width: 159px !important;" alt="DJI">
              <h2 class="block-title pb-4 mb-3">مجموعه دوربین های حرفه ای ما را بررسی کنید</h2>
              <p class="lead text-muted pb-3">شروع از <strong>۱۴,۵۰۰,۰۰۰ تومان</strong></p><a class="btn btn-style-5 btn-primary" href="shop-fw-ls.html">خرید کنید&nbsp;<i class="fe-icon-arrow-left"></i></a>
            </div>
            <div class="card-body"><img class="d-block mb-4" src="img/homepages/shop-v1/microsoft-logo.png" style="width: 170px !important;" alt="DJI">
              <h2 class="block-title pb-4 mb-3">بهره وری خود را با Surface Pro 4 / Studio </h2>
              <p class="lead text-muted pb-3">شروع از <strong>۱۱,۷۰۰,۰۰۰ تومان</strong></p><a class="btn btn-style-5 btn-primary" href="shop-fw-ls.html">خرید کنید&nbsp;<i class="fe-icon-arrow-left"></i></a>
            </div>
          </div>
        </div>
      </section>


      <section class="container pt-5 pb-4 mt-5" style="margin-bottom: 100px">
  <h2 class="h4 block-title text-center pt-4 mt-2">پیشنهاد ما</h2>
  <div class="owl-carousel carousel-flush pt-3 pb-4 owl-rtl owl-loaded owl-drag" data-owl-carousel="{ &quot;rtl&quot;: true, &quot;nav&quot;: false, &quot;dots&quot;: true, &quot;autoHeight&quot;: true, &quot;responsive&quot;: {&quot;0&quot;:{&quot;items&quot;:1},&quot;630&quot;:{&quot;items&quot;:2},&quot;991&quot;:{&quot;items&quot;:3},&quot;1200&quot;:{&quot;items&quot;:3}} }">
    <!-- Product category-->
    <div class="owl-stage-outer owl-height" style="height: 306px;"><div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0.45s ease 0s; width: 1140px;">





        <div class="owl-item active" style="width: 380px;"><a class="product-category-card mx-auto" href="shop-boxed-ls.html">
            <div class="product-category-card-thumb">
              <div class="main-img"><img src="img/shop/categories/07.jpg" alt="Shop Category">
              </div>
            </div>
            <div class="product-category-card-body">
              <div class="product-price" style="color: black">
                <del style="color:rgb(169, 169, 169);">۸۱۵,۰۰۰</del>
                ۳,۵۰۰,۰۰۰ تومان
              </div>
              <h5 class="product-category-card-title">تلویزیون، ویدئو و صوتی</h5>
            </div></a>
        </div>


        <div class="owl-item active" style="width: 380px;"><a class="product-category-card mx-auto" href="shop-boxed-ls.html">
            <div class="product-category-card-thumb">
              <div class="main-img"><img src="img/shop/categories/07.jpg" alt="Shop Category">
              </div>
            </div>
            <div class="product-category-card-body">
              <div class="product-price" style="color: black">
                <del style="color:rgb(169, 169, 169);">۸۱۵,۰۰۰</del>
                ۳,۵۰۰,۰۰۰ تومان
              </div>
              <h5 class="product-category-card-title">تلویزیون، ویدئو و صوتی</h5>
            </div></a>
        </div>



        <div class="owl-item active" style="width: 380px;"><a class="product-category-card mx-auto" href="shop-boxed-ls.html">
            <div class="product-category-card-thumb">
              <div class="main-img"><img src="img/shop/categories/07.jpg" alt="Shop Category">
              </div>
            </div>
            <div class="product-category-card-body">
              <div class="product-price" style="color: black">
                <del style="color:rgb(169, 169, 169);">۸۱۵,۰۰۰</del>
                ۳,۵۰۰,۰۰۰ تومان
              </div>
              <h5 class="product-category-card-title">تلویزیون، ویدئو و صوتی</h5>
            </div></a>
        </div>


        <div class="owl-item active" style="width: 380px;"><a class="product-category-card mx-auto" href="shop-boxed-ls.html">
            <div class="product-category-card-thumb">
              <div class="main-img"><img src="img/shop/categories/07.jpg" alt="Shop Category">
              </div>
            </div>
            <div class="product-category-card-body">
              <div class="product-price" style="color: black">
                <del style="color:rgb(169, 169, 169);">۸۱۵,۰۰۰</del>
                ۳,۵۰۰,۰۰۰ تومان
              </div>
              <h5 class="product-category-card-title">تلویزیون، ویدئو و صوتی</h5>
            </div></a>
        </div>


        <div class="owl-item active" style="width: 380px;"><a class="product-category-card mx-auto" href="shop-boxed-ls.html">
            <div class="product-category-card-thumb">
              <div class="main-img"><img src="img/shop/categories/07.jpg" alt="Shop Category">
              </div>
            </div>
            <div class="product-category-card-body">
              <div class="product-price" style="color: black">
                <del style="color:rgb(169, 169, 169);">۸۱۵,۰۰۰</del>
                ۳,۵۰۰,۰۰۰ تومان
              </div>
              <h5 class="product-category-card-title">تلویزیون، ویدئو و صوتی</h5>
            </div></a>
        </div>


        <div class="owl-item active" style="width: 380px;"><a class="product-category-card mx-auto" href="shop-boxed-ls.html">
            <div class="product-category-card-thumb">
              <div class="main-img"><img src="img/shop/categories/07.jpg" alt="Shop Category">
              </div>
            </div>
            <div class="product-category-card-body">
              <div class="product-price" style="color: black">
                <del style="color:rgb(169, 169, 169);">۸۱۵,۰۰۰</del>
                ۳,۵۰۰,۰۰۰ تومان
              </div>
              <h5 class="product-category-card-title">تلویزیون، ویدئو و صوتی</h5>
            </div></a>
        </div>


      </div>
    </div>
  </div>
</section>


      <section class="container-fluid" style="margin-bottom: 100px">
        <div class="row justify-content-center">
          <div class="col-xl-10 bg-center bg-no-repeat"><a class="d-block" href="#"><img class="d-block img-responsive" src="img/homepages/shop-v1/banner02.jpg" alt="Surface Studio" style="min-height: 600px"></a></div>
        </div>
      </section>

      <!-- Featured Products-->
      <section class="container py-5 mb-4">
        <h2 class="h4 block-title text-center pt-3">آخرین محصولات</h2>
        <div class="row pt-4">
          <?php $__currentLoopData = $prodoct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <!-- Product-->
          <div class="col-lg-3 col-md-4 col-sm-6 mb-30">
            <div class="product-card mx-auto mb-3">
              <a class="product-thumb" href="/prodoct/<?php echo e($value->seo); ?>"><img src="/img/prodoct/<?php echo e($value->pic); ?>" alt="Product Thumbnail"/></a>

              <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($value->dasteh3==$val->id): ?>
                  <?php  $cat=$val->name_menu;  ?>
                 <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


              <?php  $classfave='fe-icon-heart';  ?>
               <?php $__currentLoopData = $fav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($val->prodoct_id==$value->id): ?>
                   <?php  $classfave= 'fa fa-heart'; break;  ?>
                  <?php else: ?>
                   <?php   $classfave= 'fe-icon-heart';  ?>
                  <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




              <div class="product-card-body"><a class="product-meta" href="#"><?php echo e($cat); ?></a>
                <h5 class="product-title"><a href="/prodoct/<?php echo e($value->seo); ?>"><?php echo e($value->name); ?></a></h5><span class="product-price">
                  <?php if($value->takhfif!=0): ?>
                  <?php echo e(number_format($value->takhfif)); ?>


                  <del><?php echo e(number_format($value->gheymat)); ?></del>
                    <?php else: ?>
                    <?php echo e(number_format($value->gheymat)); ?>

                  <?php endif; ?>
                  تومان</span>
              </div>
              <div class="product-buttons-wrap">
                <div class="product-buttons">
                  <?php if(! session('login')): ?>
                  <div class="product-button"><a href="/account-login"><i class="fe-icon-heart"></i></a></div>
                    <?php else: ?>
                        <div class="product-button"><a href="#" onclick="add_fav(<?php echo e($value->id); ?>)" data-toast data-toast-position="topRight" data-toast-type="info" data-toast-icon="fe-icon-help-circle" data-toast-title="علاقه مندی" data-toast-message="با موفقیت انجام گردید"><i  id="class<?php echo e($value->id); ?>" class="<?php echo e($classfave); ?>"></i></a></div>
                  <?php endif; ?>
                  <div class="product-button"><a href="#" onclick="sabad(<?php echo e($value->id); ?>)" data-toast data-toast-position="topRight" data-toast-type="success" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!"><i class="fe-icon-shopping-cart"></i></a></div>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="text-center pt-3"><a class="btn btn-style-5 btn-primary" href="shop-boxed-ls.html">مشاهده تمام محصولات</a></div>
      </section>



      <!-- Promo #1-->
      <section class="container-fluid pt-5" style="margin-top: 70px;">
        <h2 class="h4 block-title text-center pt-4 mt-2">پیشنهادات ویژه</h2>
        <div style="margin-top: 30px;" class="row justify-content-center">
          <div class="col-xl-5 col-lg-6 mb-30">
            <div class="bg-secondary position-relative pb-5"><span class="badge badge-danger mt-4 ml-4">پیشنهاد محدود</span>
              <div class="text-center pt-4">
                <h3 class="font-family-body font-weight-light mb-2">محصولات جدید</h3>
                <h2 class="mb-2 pb-1">MacBook Pro 2018</h2>
                <h5 class="font-family-body font-weight-light mb-5">قیمت با تخفیف. عجله کن!</h5>
                <div class="countdown countdown-style-2 h4 mb-3 direction-ltr" data-date-time="10/10/2020 12:00" data-labels="{&quot;label-day&quot;: &quot;روز&quot;, &quot;label-hour&quot;: &quot;ساعت&quot;, &quot;label-minute&quot;: &quot;دقیقه&quot;, &quot;label-second&quot;: &quot;ثانیه&quot;}"></div><br><a class="btn btn-style-5 btn-gradient mb-3" href="#">مشاهده پیشنهادات</a>
              </div>
            </div>
          </div>
          <div class="col-xl-5 col-lg-6 mb-30">
            <div class="bg-secondary position-relative pb-5"><span class="badge badge-danger mt-4 ml-4">پیشنهاد محدود</span>
              <div class="text-center pt-4">
                <h3 class="font-family-body font-weight-light mb-2">محصولات جدید</h3>
                <h2 class="mb-2 pb-1">MacBook Pro 2018</h2>
                <h5 class="font-family-body font-weight-light mb-5">قیمت با تخفیف. عجله کن!</h5>
                <div class="countdown countdown-style-2 h4 mb-3 direction-ltr" data-date-time="10/10/2020 12:00" data-labels="{&quot;label-day&quot;: &quot;روز&quot;, &quot;label-hour&quot;: &quot;ساعت&quot;, &quot;label-minute&quot;: &quot;دقیقه&quot;, &quot;label-second&quot;: &quot;ثانیه&quot;}"></div><br><a class="btn btn-style-5 btn-gradient mb-3" href="#">مشاهده پیشنهادات</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- Promo #1-->


      <!-- Featured Products-->
      <section class="container py-5 mb-4">
  <h2 class="h4 block-title text-center pt-3">محصولات تخفیف دار</h2>
  <div class="row pt-4">
    <?php $__currentLoopData = $takhfif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Product-->
    <div class="col-lg-3 col-md-4 col-sm-6 mb-30">
      <div class="product-card mx-auto mb-3">
        <a class="product-thumb" href="/prodoct/<?php echo e($value->seo); ?>"><img src="img/prodoct/<?php echo e($value->pic); ?>" alt="Product Thumbnail"/></a>

        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($value->dasteh3==$val->id): ?>
            <?php  $cat=$val->name_menu;  ?>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="product-card-body"><a class="product-meta" href="#"><?php echo e($cat); ?></a>
          <h5 class="product-title"><a href="/prodoct/<?php echo e($value->seo); ?>"><?php echo e($value->name); ?></a></h5><span class="product-price">
                  <?php echo e($value->takhfif); ?><del><?php echo e($value->gheymat); ?></del> تومان</span>
        </div>
        <div class="product-buttons-wrap">
          <div class="product-buttons">
            <?php if(! session('login')): ?>
              <div class="product-button"><a href="/account-login"><i class="fe-icon-heart"></i></a></div>
            <?php else: ?>
              <div class="product-button"><a href="#" onclick="add_fav(<?php echo e($value->id); ?>)" data-toast data-toast-position="topRight" data-toast-type="info" data-toast-icon="fe-icon-help-circle" data-toast-title="محصول" data-toast-message="به علاقمندی اضافه شد!"><i class="fe-icon-heart"></i></a></div>
            <?php endif; ?>
              <div class="product-button"><a href="#" onclick="sabad(<?php echo e($value->id); ?>)" data-toast data-toast-position="topRight" data-toast-type="success" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!"><i class="fe-icon-shopping-cart"></i></a></div>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="text-center pt-3"><a class="btn btn-style-5 btn-primary" href="shop-boxed-ls.html">مشاهده تمام محصولات</a></div>
</section>



      <!-- Promo #1-->
      <section class="container-fluid pt-5" style="margin-top: 100px;">
        <h2 class="h4 block-title text-center pt-4 mt-2">پیشنهادات ویژه</h2>
        <div style="margin-top: 30px;" class="row justify-content-center">
          <div class="col-xl-5 col-lg-6 mb-30">
            <div class="bg-secondary position-relative pb-5"><span class="badge badge-danger mt-4 ml-4">پیشنهاد محدود</span>
              <div class="text-center pt-4">
                <h3 class="font-family-body font-weight-light mb-2">محصولات جدید</h3>
                <h2 class="mb-2 pb-1">MacBook Pro 2018</h2>
                <h5 class="font-family-body font-weight-light mb-5">قیمت با تخفیف. عجله کن!</h5>
                <div class="countdown countdown-style-2 h4 mb-3 direction-ltr" data-date-time="10/10/2020 12:00" data-labels="{&quot;label-day&quot;: &quot;روز&quot;, &quot;label-hour&quot;: &quot;ساعت&quot;, &quot;label-minute&quot;: &quot;دقیقه&quot;, &quot;label-second&quot;: &quot;ثانیه&quot;}"></div><br><a class="btn btn-style-5 btn-gradient mb-3" href="#">مشاهده پیشنهادات</a>
              </div>
            </div>
          </div>
          <div class="col-xl-5 col-lg-6 mb-30">
            <div class="bg-secondary position-relative pb-5"><span class="badge badge-danger mt-4 ml-4">پیشنهاد محدود</span>
              <div class="text-center pt-4">
                <h3 class="font-family-body font-weight-light mb-2">محصولات جدید</h3>
                <h2 class="mb-2 pb-1">MacBook Pro 2018</h2>
                <h5 class="font-family-body font-weight-light mb-5">قیمت با تخفیف. عجله کن!</h5>
                <div class="countdown countdown-style-2 h4 mb-3 direction-ltr" data-date-time="10/10/2020 12:00" data-labels="{&quot;label-day&quot;: &quot;روز&quot;, &quot;label-hour&quot;: &quot;ساعت&quot;, &quot;label-minute&quot;: &quot;دقیقه&quot;, &quot;label-second&quot;: &quot;ثانیه&quot;}"></div><br><a class="btn btn-style-5 btn-gradient mb-3" href="#">مشاهده پیشنهادات</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- Promo #1-->



      <!-- Featured Products-->
      <section class="container py-5 mb-4">
        <h2 class="h4 block-title text-center pt-3">پرفروش ترین محصولات</h2>
        <div class="row pt-4">
          <!-- Product-->
          <div class="col-lg-3 col-md-4 col-sm-6 mb-30">
            <div class="product-card mx-auto mb-3">
              <a class="product-thumb" href="shop-single.html"><img src="img/shop/01.jpg" alt="Product Thumbnail"/></a>
              <div class="product-card-body"><a class="product-meta" href="shop-categories.html">اسپیکر(بلندگو)</a>
                <h5 class="product-title"><a href="shop-single.html">دستیار صوتی آمازون</a></h5><span class="product-price">
                        ۷۵۸,۰۰۰<del>۸۱۵,۰۰۰</del> تومان</span>
              </div>
              <div class="product-buttons-wrap">
                <div class="product-buttons">
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="info" data-toast-icon="fe-icon-help-circle" data-toast-title="محصول" data-toast-message="به علاقمندی اضافه شد!"><i class="fe-icon-heart"></i></a></div>
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="success" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!"><i class="fe-icon-shopping-cart"></i></a></div>
                </div>
              </div>
            </div>
          </div>
          <!-- Product-->
          <div class="col-lg-3 col-md-4 col-sm-6 mb-30">
            <div class="product-card mx-auto mb-3">
              <a class="product-thumb" href="shop-single.html"><img src="img/shop/11.jpg" alt="Product Thumbnail"/></a>
              <div class="product-card-body"><a class="product-meta" href="shop-categories.html">هدفون</a>
                <h5 class="product-title"><a href="shop-single.html">هدفون Edifier W855BT</a></h5><span class="product-price">۴,۱۸۹,۰۰۰ تومان</span>
              </div>
              <div class="product-buttons-wrap">
                <div class="product-buttons">
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="info" data-toast-icon="fe-icon-help-circle" data-toast-title="محصول" data-toast-message="به علاقمندی اضافه شد!"><i class="fe-icon-heart"></i></a></div>
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="success" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!"><i class="fe-icon-shopping-cart"></i></a></div>
                </div>
              </div>
            </div>
          </div>
          <!-- Product-->
          <div class="col-lg-3 col-md-4 col-sm-6 mb-30">
            <div class="product-card mx-auto mb-3">
              <a class="product-thumb" href="shop-single.html"><img src="img/shop/03.jpg" alt="Product Thumbnail"/></a>
              <div class="product-card-body"><a class="product-meta" href="shop-categories.html">کامپیوتر, لپ تاپ</a>
                <h5 class="product-title"><a href="shop-single.html">تبلت Microsoft Surface Pro 4</a></h5><span class="product-price text-muted">۶,۵۴۰,۰۰۰ تومان</span>
              </div>
              <div class="product-buttons-wrap">
                <div class="product-buttons">
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="info" data-toast-icon="fe-icon-help-circle" data-toast-title="محصول" data-toast-message="به علاقمندی اضافه شد!"><i class="fe-icon-heart"></i></a></div>
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="success" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!"><i class="fe-icon-shopping-cart"></i></a></div>
                </div>
              </div>
            </div>
          </div>
          <!-- Product-->
          <div class="col-lg-3 col-md-4 col-sm-6 mb-30">
            <div class="product-card mx-auto mb-3">
              <a class="product-thumb" href="shop-single.html"><img src="img/shop/09.jpg" alt="Product Thumbnail"/></a>
              <div class="product-card-body"><a class="product-meta" href="shop-categories.html">دوربین</a>
                <h5 class="product-title"><a href="shop-single.html">دوربین 360 درجه سامسونگ</a></h5><span class="product-price">۸۸۰,۰۰۰ تومان</span>
              </div>
              <div class="product-buttons-wrap">
                <div class="product-buttons">
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="info" data-toast-icon="fe-icon-help-circle" data-toast-title="محصول" data-toast-message="به علاقمندی اضافه شد!"><i class="fe-icon-heart"></i></a></div>
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="success" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!"><i class="fe-icon-shopping-cart"></i></a></div>
                </div>
              </div>
            </div>
          </div>
          <!-- Product-->
          <div class="col-lg-3 col-md-4 col-sm-6 mb-30">
            <div class="product-card mx-auto mb-3">
              <a class="product-thumb" href="shop-single.html"><img src="img/shop/04.jpg" alt="Product Thumbnail"/></a>
              <div class="product-card-body"><a class="product-meta" href="shop-categories.html">گوشی های هوشمند</a>
                <h5 class="product-title"><a href="shop-single.html">Apple iPhone X 64GB Space Gray</a></h5><span class="product-price">۱۵,۳۹۰,۰۰۰ تومان</span>
              </div>
              <div class="product-buttons-wrap">
                <div class="product-buttons">
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="info" data-toast-icon="fe-icon-help-circle" data-toast-title="محصول" data-toast-message="به علاقمندی اضافه شد!"><i class="fe-icon-heart"></i></a></div>
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="success" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!"><i class="fe-icon-shopping-cart"></i></a></div>
                </div>
              </div>
            </div>
          </div>
          <!-- Product-->
          <div class="col-lg-3 col-md-4 col-sm-6 mb-30">
            <div class="product-card mx-auto mb-3">
              <a class="product-thumb" href="shop-single.html"><img src="img/shop/06.jpg" alt="Product Thumbnail"/></a>
              <div class="product-card-body"><a class="product-meta" href="shop-categories.html">کنسول بازی</a>
                <h5 class="product-title"><a href="shop-single.html">کنسول بازی مایکروسافت</a></h5><span class="product-price">۲,۸۱۳,۰۰۰ تومان</span>
              </div>
              <div class="product-buttons-wrap">
                <div class="product-buttons">
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="info" data-toast-icon="fe-icon-help-circle" data-toast-title="محصول" data-toast-message="به علاقمندی اضافه شد!"><i class="fe-icon-heart"></i></a></div>
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="success" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!"><i class="fe-icon-shopping-cart"></i></a></div>
                </div>
              </div>
            </div>
          </div>
          <!-- Product-->
          <div class="col-lg-3 col-md-4 col-sm-6 mb-30">
            <div class="product-card mx-auto mb-3">
              <a class="product-thumb" href="shop-single.html"><img src="img/shop/08.jpg" alt="Product Thumbnail"/></a>
              <div class="product-card-body"><a class="product-meta" href="shop-categories.html">تلویزیون، ویدئو و صوتی</a>
                <h5 class="product-title"><a href="shop-single.html">تلویزیون Sony 55-Inch 4K</a></h5><span class="product-price">۱۲,۵۰۰,۰۰۰ تومان</span>
              </div>
              <div class="product-buttons-wrap">
                <div class="product-buttons">
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="info" data-toast-icon="fe-icon-help-circle" data-toast-title="محصول" data-toast-message="به علاقمندی اضافه شد!"><i class="fe-icon-heart"></i></a></div>
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="success" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!"><i class="fe-icon-shopping-cart"></i></a></div>
                </div>
              </div>
            </div>
          </div>
          <!-- Product-->
          <div class="col-lg-3 col-md-4 col-sm-6 mb-30">
            <div class="product-card mx-auto mb-3">
              <a class="product-thumb" href="shop-single.html"><img src="img/shop/10.jpg" alt="Product Thumbnail"/></a>
              <div class="product-card-body"><a class="product-meta" href="shop-categories.html">چاپگرها</a>
                <h5 class="product-title"><a href="shop-single.html">Hewlett-Packard</a></h5><span class="product-price">
                        ۷۵۸,۰۰۰<del>۸۱۵,۰۰۰</del> تومان</span>
              </div>
              <div class="product-buttons-wrap">
                <div class="product-buttons">
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="info" data-toast-icon="fe-icon-help-circle" data-toast-title="محصول" data-toast-message="به علاقمندی اضافه شد!"><i class="fe-icon-heart"></i></a></div>
                  <div class="product-button"><a href="#" data-toast data-toast-position="topRight" data-toast-type="success" data-toast-icon="fe-icon-check-circle" data-toast-title="محصول" data-toast-message="با موفقیت به سبد خرید اضافه شد!"><i class="fe-icon-shopping-cart"></i></a></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="text-center pt-3"><a class="btn btn-style-5 btn-primary" href="shop-boxed-ls.html">مشاهده تمام محصولات</a></div>
      </section>

      <!-- Popular Brands-->
      <section class="bg-secondary pt-5 pb-4">
        <div class="container pt-3 pb-2">
          <h2 class="h4 block-title text-center">برند های محبوب</h2>
          <div class="owl-carousel carousel-flush pt-3" data-owl-carousel="{ &quot;rtl&quot;: true, &quot;nav&quot;: false, &quot;dots&quot;: true, &quot;autoplay&quot;: true, &quot;autoplayTimeout&quot;: 3500, &quot;loop&quot;: true, &quot;autoHeight&quot;: true, &quot;responsive&quot;: {&quot;0&quot;:{&quot;items&quot;:1},&quot;360&quot;:{&quot;items&quot;:2},&quot;600&quot;:{&quot;items&quot;:3},&quot;991&quot;:{&quot;items&quot;:4},&quot;1200&quot;:{&quot;items&quot;:4}} }"><a class="d-block bg-white box-shadow py-4 py-sm-5 px-2 mb-30" href="#"><img class="d-block mx-auto" src="img/partners/10.png" style="width: 165px;" alt="Partner"></a><a class="d-block bg-white box-shadow py-4 py-sm-5 px-2 mb-30" href="#"><img class="d-block mx-auto" src="img/partners/11.png" style="width: 165px;" alt="Partner"></a><a class="d-block bg-white box-shadow py-4 py-sm-5 px-2 mb-30" href="#"><img class="d-block mx-auto" src="img/partners/14.png" style="width: 165px;" alt="Partner"></a><a class="d-block bg-white box-shadow py-4 py-sm-5 px-2 mb-30" href="#"><img class="d-block mx-auto" src="img/partners/13.png" style="width: 165px;" alt="Partner"></a><a class="d-block bg-white box-shadow py-4 py-sm-5 px-2 mb-30" href="#"><img class="d-block mx-auto" src="img/partners/12.png" style="width: 165px;" alt="Partner"></a><a class="d-block bg-white box-shadow py-4 py-sm-5 px-2 mb-30" href="#"><img class="d-block mx-auto" src="img/partners/15.png" style="width: 165px;" alt="Partner"></a><a class="d-block bg-white box-shadow py-4 py-sm-5 px-2 mb-30" href="#"><img class="d-block mx-auto" src="img/partners/16.png" style="width: 165px;" alt="Partner"></a><a class="d-block bg-white box-shadow py-4 py-sm-5 px-2 mb-30" href="#"><img class="d-block mx-auto" src="img/partners/17.png" style="width: 165px;" alt="Partner"></a></div>
        </div>
      </section>
      <!-- Shop Services-->
      <section class="container py-5">
        <div class="row pt-3">
          <div class="col-md-3 col-sm-6 text-center mb-30"><img class="mx-auto mb-4" src="img/shop/services/01.png" width="90" alt="Free Worldwide Shipping">
            <h3 class="text-lg mb-2 text-body">حمل و نقل رایگان در سراسر جهان</h3>
            <p class="text-sm text-muted mb-0">حمل و نقل رایگان برای تمام سفارشات بیشتر از 100 دلار</p>
          </div>
          <div class="col-md-3 col-sm-6 text-center mb-30"><img class="mx-auto mb-4" src="img/shop/services/02.png" width="90" alt="Money Back Guarantee">
            <h3 class="text-lg mb-2 text-body">تضمین بازگشت پول</h3>
            <p class="text-sm text-muted mb-0">ما پول را در عرض ۳۰ روز برمی گردانیم.</p>
          </div>
          <div class="col-md-3 col-sm-6 text-center mb-30"><img class="mx-auto mb-4" src="img/shop/services/03.png" width="90" alt="24/7 Customer Support">
            <h3 class="text-lg mb-2 text-body">پشتیبانی مشتری 24/7</h3>
            <p class="text-sm text-muted mb-0">پشتیبانی دوستانه</p>
          </div>
          <div class="col-md-3 col-sm-6 text-center mb-30"><img class="mx-auto mb-4" src="img/shop/services/04.png" width="90" alt="Secure Online Payment">
            <h3 class="text-lg mb-2 text-body">پرداخت آنلاین ایمن</h3>
            <p class="text-sm text-muted mb-0">ما دارای گواهی SSL / Secure هستیم</p>
          </div>
        </div>
      </section>

<?php echo $__env->yieldContent('footer'); ?>