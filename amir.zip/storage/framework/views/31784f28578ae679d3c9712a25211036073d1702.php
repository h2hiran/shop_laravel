<?php
use Illuminate\Support\Facades\Session;
?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('header'); ?>
    <!-- Page Title-->
    <div class="page-title d-flex" aria-label="Page title" style="background-image: url(img/page-title/shop-pattern.jpg);">
        <div class="container text-right align-self-center">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">صفحه اصلی</a>
                    </li>
                    <li class="breadcrumb-item"><a href="shop-boxed-ls.html">فروشگاه</a>
                    </li>
                </ol>
            </nav>
            <h1 class="page-title-heading">سبد خرید</h1>
        </div>
    </div>
    <!-- Page Content-->
    <div class="container pb-5 mb-2">
        <!-- Alert-->
    <form method="post" action="/update_sabad">
        <?php echo e(csrf_field()); ?>

        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Cart Item-->
        <div id="sabad<?php echo e($value->id); ?>" class="cart-item d-md-flex justify-content-between"><span onclick="cart(<?php echo e($value->id); ?>)" class="remove-item"><i class="fe-icon-x"></i></span>
            <div class="px-3 my-3"><a class="cart-item-product" href="shop-single.html">
                    <div class="cart-item-product-thumb"><img src="/img/prodoct/<?php echo e($value->options->img); ?>" alt="Product"></div>
                    <div class="cart-item-product-info">
                        <h4 class="cart-item-product-title"><?php echo e($value->name); ?></h4>
                    </div></a></div>
            <div class="px-3 my-3 text-center">
                <div class="cart-item-label">تعداد</div>
                <div class="count-input">
                   <input type="number" name="<?php echo e($value->rowId); ?>" class="form-control" value="<?php echo e($value->qty); ?>" required>
                </div>
            </div>
            <div class="px-3 my-3 text-center">
                <div class="cart-item-label">قیمت</div><span class="text-xl font-weight-medium"><?php echo e(number_format($value->price)); ?></span>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        <!-- Coupon + Subtotal-->
        <div class="d-sm-flex justify-content-between align-items-center text-center text-sm-right">
            <div class="form-inline py-2"></div>
            <div class="py-2"><span class="d-inline-block align-middle text-sm text-muted font-weight-medium text-uppercase ml-2">مجموع:</span><span class="d-inline-block align-middle text-xl font-weight-medium"><?php echo e(number_format(Cart::subtotal())); ?></span></div>
        </div>
        <!-- Buttons-->
        <hr class="my-2">
        <div class="row pt-3 pb-5 mb-2">
            <div class="col-sm-6 mb-3"><input type="submit" value="به روز رسانی سبد خرید" class="btn btn-secondary btn-block"></div>
            <div class="col-sm-6 mb-3"><a class="btn btn-primary btn-block" href="checkout-address.html"><i class="fe-icon-credit-card"></i>&nbsp; پرداخت</a></div>
        </div>
    </form>
    </div>
<?php echo $__env->yieldContent('footer'); ?>