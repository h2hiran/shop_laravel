<?php 
     $listbrand=1;
      $brand=1;
 ?>


<?php $__env->startSection('cat'); ?>
    <h1 class="m-0 text-dark">لیست گروه بندی</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <script>
        setTimeout(function(){
            $('#alert').remove();
        }, 2000);
    </script>
    <div class="card card-primary">
        <?php if(! isset($_GET['status'])): ?>
            <div class="card-header" style="margin-bottom: 20px">
                <h3 class="card-title"></h3>
            </div>
        <?php else: ?>
            <div class="card-header" style="margin-bottom: 20px;background-color: #980110">
                <h3 id="alert" class="card-title">ارور: ابتدا زیر گروه را پاک کنید</h3>
            </div>
        <?php endif; ?>
        <table class="table table-bordered table-striped" id="example1">
            <thead>
            <tr style="text-align: center">
                <th scope="col">#</th>
                <th scope="col">نام</th>
                <th scope="col">seo</th>
                <th scope="col">ویرایش</th>
                <th scope="col">حذف</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($value->id); ?></th>
                    <td><?php echo e($value->name); ?></td>
                    <td><?php echo e($value->seo); ?></td>
                    <td><a href="/admin/edite-brand/<?php echo e($value->id); ?>" class="btn fa fa-edit"></a></td>
                    <td><a href="/admin/delete-brand/<?php echo e($value->id); ?>" class="btn fa fa-trash" onclick="return confirm('آیا مطمئن هستید؟')"></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('java'); ?>
    <script>
        $(function () {
            $("#example1").DataTable({
                "language": {
                    "paginate": {
                        "next": "بعدی",
                        "previous" : "قبلی"
                    }
                },
                "info" : false,
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php 
    $listbrand=0;
        $brand=0;
 ?>
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>