<?php 
    $addprodoct=1;
    $prodoct=1;
 ?>





<?php $__env->startSection('cat'); ?>
<h1 class="m-0 text-dark">اضافه کردن محصول</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <script>
        setTimeout(function(){
            $('#alert').remove();
        }, 2000);
    </script>
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">اطلاعات را کامل کنید</h3>
        </div>
        <?php if(Session::pull('ok')): ?>
            <br>
            <span id="alert" class="alert alert-success"><label>ذخیره با موفقیت انجام گردید</label></span>
    <?php endif; ?>
        <!-- /.card-header -->
        <!-- form start -->
        <form role="form" action="/admin/store-prodoct" method="post" id="form" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="card-body">
                <div class="form-group">
                    <label for="name">نام محصول</label>
                    <input type="text" class="form-control <?php if($errors->first('name')): ?> border-danger <?php endif; ?>" id="name"  name="name" placeholder="نام محصول را وارد کنید" value="<?php echo e(old('name')); ?>" required>

                </div><br>
                <div class="form-group">
                    <label for="seo">آدرس url</label>
                    <input type="text" class="form-control <?php if($errors->first('seo')): ?> border-danger <?php endif; ?>" id="seo" name="seo" placeholder="آدرس url را وارد کنید" required>
                </div><br>


             <div class="form-group col-sm-12">
                 <label for="sub">زیرگروه اول</label>
                 <select id="sub" class="form-control" name="sub">
                     <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($value->id); ?>"><?php echo e($value->name_menu); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
             </div><br>

                <div class="form-group col-sm-12">
                    <label for="sub1">زیرگروه دوم</label>
                    <select id="sub1" class="form-control" name="sub1">
                        <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name_menu); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div><br>


                <div class="form-group col-sm-12">
                    <label for="sub2"> زیرگروه سوم</label>
                    <select id="sub2" class="form-control" name="sub2">
                        <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name_menu); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div><br>

                <div class="form-group col-sm-12">
                    <label for="brand"> برند</label>
                    <select class="form-control" name="brand">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div><br>

                <div class="form-group">
                    <label for="gheymat">قیمت به تومان</label>
                    <input type="number" class="form-control" id="gheymat" name="gheymat" placeholder="قیمت را وارد کنید" required>
                </div><br>

                <div class="form-group">
                    <label for="takhfif">قیمت تخفیف به تومان</label>
                    <input type="number" class="form-control" id="takhfif" name="takhfif" placeholder="قیمت تخفیف را وارد کنید" required>
                </div><br>

                <div class="form-group">
                    <label for="vizh">ویژگی های محصول</label>
                    <!-- the tag stuff -->
                    <input id="tagArray" name="vizh" type="hidden" class="form-control"/>
                    <input id="transientTagField" type="text" pattern="^([a-zA-Z0-9\.\-+]{2,20},?)+$"
                           title="Min: 2 Chars and only [a-z,+,-,.]" placeholder="ویژگی های محصول را وارد کنید"
                           class="form-control  <?php if($errors->first('vizh')): ?> border-danger <?php endif; ?>"/>
                    <div id="tagContainer" class="inline form-control"></div>
                    <input type="submit" id="validate" style="position: absolute; left: -9999px" class="form-control"/>
                </div><br>

                <div class="form-group">
                    <label for="estefadeh">نحوه استفاده</label>
                    <textarea id="estefadeh" class="form-control ckeditor" name="estefadeh"></textarea>
                </div><br>

                <div class="form-group">
                    <label for="dis">توضیحات</label>
                    <textarea id="dis" class="form-control" name="dis" required></textarea>
                </div><br>


                <div class="form-group">
                    <label for="pic">ارسال فایل</label>
                    <input type="file" class="form-control" id="image_uploads" name="pic" accept=".jpg, .jpeg, .png" required>
                </div><br>

                <div class="form-group">
                    <label for="check">انتخاب</label><br>
                    <input type="checkbox" class="checkbox" name="ma" > پیشنهاد ما <br>
                    <input type="checkbox" class="checkbox" name="good" > پیشنهاد ویژه
                </div><br>

            </div>
            <!-- /.card-body -->

            <div class="card-footer">
                <button type="submit" class="btn btn-primary">ارسال</button>
            </div>
        </form>
    </div>



    <script>
        CKEDITOR.replace( 'ckeditor',
            {
                customConfig : 'config.js',
                toolbar : 'simple'
            })
    </script>
<?php $__env->stopSection(); ?>

<?php 
    $addprodoct=0;
    $prodoct=0;
 ?>
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>