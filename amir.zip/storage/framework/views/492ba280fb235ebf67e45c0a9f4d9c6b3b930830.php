<?php 
    $listprodoct=1;
    $prodoct=1;
 ?>




<?php $__env->startSection('cat'); ?>
    <h1 class="m-0 text-dark">ویرایش کردن</h1>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <script>
        setTimeout(function(){
            $('#alert').remove();
        }, 2000);
    </script>
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">اطلاعات را کامل کنید</h3>
        </div>
        <?php if(isset($ok)): ?>
            <br>
            <span id="alert" class="alert alert-success"><label>ذخیره با موفقیت انجام گردید</label></span>
        <?php endif; ?>
        <!-- /.card-header -->
        <!-- form start -->
        <form role="form" method="post" action="/admin/list-menu/edite-menu/update/<?php echo e($data->id); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="card-body">
                <div class="form-group">
                    <label for="name">نام</label>
                    <input type="text" name="name" class="form-control" id="name" placeholder="نام دسته بندی را وارد کنید" required value="<?php echo e($data->name); ?>">
                </div>
                <div class="form-group">
                    <label for="url">آدرس url</label>
                    <input type="text" name="seo" class="form-control" id="url" placeholder="آدرس url را وارد کنید" required value="<?php echo e($data->seo); ?>">
                </div>

                <div class="form-group">
                    <label for="url">توضیحات</label>
                    <textarea id="dis" class="form-control ckeditor" name="dis" required><?php echo e($data->dis); ?></textarea>
                </div>

                <div class="form-group">
                    <input class="btn btn-success" type="submit" value="ذخیره">
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php 
    $listprodoct=0;
  $prodoct=0;
 ?>
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>