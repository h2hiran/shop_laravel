<?php 
    if ($id==0)
         $addgroup0=1;
    elseif ($id==1)
          $addgroup1=1;
          else
          $addgroup2=1;

    $group=1;

 ?>




<?php $__env->startSection('cat'); ?>
    <h1 class="m-0 text-dark">اضافه کردن منو</h1>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <script>
        setTimeout(function(){
            $('#alert').remove();
        }, 2000);
    </script>
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">اطلاعات را کامل کنید</h3>
        </div>
        <?php if(Session::pull('ok')): ?>
            <br>
            <span id="alert" class="alert alert-success"><label>ذخیره با موفقیت انجام گردید</label></span>
        <?php endif; ?>
        <!-- /.card-header -->
        <!-- form start -->
        <form role="form" method="post" action="/admin/add-menu/store/<?php echo e($id); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="card-body">
                <div class="form-group">
                    <label for="name">نام منو</label>
                    <input type="text" name="name" class="form-control" id="name" placeholder="نام را وارد کنید" required>
                </div>
                <div class="form-group">
                    <label for="seo">آدرس url</label>
                    <input type="text" name="seo" class="form-control" id="seo" placeholder="آدرس url را وارد کنید" required>
                </div>

                <?php if($id==1 || $id==2): ?>
                    <div class="form-group">
                        <label for="seo">سرگروه</label>
                        <select class="form-control" name="parent" required>
                            <?php $__currentLoopData = $men; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name_menu); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                <?php endif; ?>

                <div class="form-group">
                    <input class="btn btn-success" type="submit" value="ذخیره">
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php 
    if ($id==0)
         $addgroup0=0;
    elseif ($id==1)
          $addgroup1=0;
          else
          $addgroup2=0;

    $group=0;
 ?>
<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>